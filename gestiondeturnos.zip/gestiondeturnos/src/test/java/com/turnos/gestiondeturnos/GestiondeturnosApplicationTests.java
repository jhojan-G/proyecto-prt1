package com.turnos.gestiondeturnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestiondeturnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
