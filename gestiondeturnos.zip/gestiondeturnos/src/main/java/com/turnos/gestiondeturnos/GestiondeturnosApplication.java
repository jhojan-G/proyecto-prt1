package com.turnos.gestiondeturnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestiondeturnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestiondeturnosApplication.class, args);
	}

}
